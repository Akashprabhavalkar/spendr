import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  Formdata: any
  data: any;
  constructor(private router: Router) {
    this.data = JSON.parse(localStorage.getItem('Users')|| '{}')
    console.log("==data", this.data)
  }

  ngOnInit(): void {
    // this.router.navigate(["/list"])

    // if(localStorage.getItem("user") != null)
    // {
    //   this.router.navigate(['/list']
    // }

    this.Formdata = new FormGroup(
      {
        email: new FormControl("", Validators.required),

        Password: new FormControl("", Validators.compose([Validators.minLength(6)])),
      }
    )
  }


  submit(Formdata:any) {
    console.log("formdata",Formdata)
    for (let item of this.data){
      console.log("==item",item);
      if(item.email == Formdata.email  && item.Password == Formdata.Password){
        let user = {email:Formdata.email, Password:Formdata.Password};
        localStorage.setItem("user", JSON.stringify(user));
        this.router.navigate(['/user-list']);
      }
      else{
      }
    }
   

    // let user = {email:Formdata.email, Password:Formdata.Password};

    // this.Formdata.value = this.Formdata.email
    // this.Formdata.value = this.Formdata.Password
    // let data = localStorage.setItem("user",JSON.stringify(user))

    //  this.router.navigate(['/list'])

  }

  signup() {
    this.router.navigate(['/register'])

  }
}


